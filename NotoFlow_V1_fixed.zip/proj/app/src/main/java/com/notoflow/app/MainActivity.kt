package com.notoflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Note(val id: Long, val title: String, val body: String, val done: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NotoFlowApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotoFlowApp() {
    var selected by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf(listOf(
        Note(1, "Welcome to NotoFlow", "Your notes, tasks and lists in one place.")
    )) }
    val tabs = listOf("Home", "Tasks", "Calendar", "Notes", "More")

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("NotoFlow") },
                    actions = { Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()),
                        modifier = Modifier.padding(end = 16.dp)) }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = selected == i,
                            onClick = { selected = i },
                            icon = { Text(listOf("⌂","✓","□","▤","⋯")[i]) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            when (selected) {
                0 -> HomeScreen(notes, Modifier.padding(pad))
                1 -> TasksScreen(Modifier.padding(pad))
                2 -> CalendarScreen(Modifier.padding(pad))
                3 -> NotesScreen(notes, Modifier.padding(pad)) { id -> notes = notes.filterNot { it.id == id } }
                else -> MoreScreen(Modifier.padding(pad))
            }
        }
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("New note") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") })
                    OutlinedTextField(body, { body = it }, label = { Text("Note") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank() || body.isNotBlank()) {
                        notes = notes + Note(System.currentTimeMillis(), title.ifBlank { "Untitled" }, body)
                    }
                    showAdd = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }
}

@Composable fun HomeScreen(notes: List<Note>, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Good morning 👋", style = MaterialTheme.typography.headlineSmall)
        Text("Everything you need to remember, in one place.")
        Card { Column(Modifier.padding(16.dp)) { Text("Today's Progress"); Text("0 / 0 tasks completed") } }
        Text("Recent Notes", style = MaterialTheme.typography.titleLarge)
        notes.take(3).forEach { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(it.title, style=MaterialTheme.typography.titleMedium); Text(it.body) } } }
    }
}

@Composable fun NotesScreen(notes: List<Note>, modifier: Modifier, onDelete: (Long) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Notes", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(notes) { note ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(note.title, style=MaterialTheme.typography.titleMedium)
                        Text(note.body)
                        TextButton(onClick = { onDelete(note.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
@Composable fun TasksScreen(modifier: Modifier) { EmptyPage(modifier, "Tasks", "No tasks yet. Tap + to create a note; task creation is next in V1.") }
@Composable fun CalendarScreen(modifier: Modifier) { EmptyPage(modifier, "Calendar", "Calendar and events are planned for the next V1 milestone.") }
@Composable fun MoreScreen(modifier: Modifier) { EmptyPage(modifier, "More", "Labels, archive, trash, templates and settings will be added incrementally.") }
@Composable fun EmptyPage(modifier: Modifier, title: String, message: String) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style=MaterialTheme.typography.headlineSmall); Text(message)
    }
}
