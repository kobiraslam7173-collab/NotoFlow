# NotoFlow V1 — Android starter project

This is the first working milestone: Android/Jetpack Compose app structure, navigation, home screen, notes list and real note creation.

## Build
Open this folder in Android Studio with Android SDK installed, or import it into a compatible Android build service.
Then run:
`./gradlew assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Next milestones
1. Persistent Room/local database
2. Checklist + shopping list
3. Tasks + reminders/notifications
4. Calendar/events
5. Search, labels, pin, archive, trash
6. Dark mode, backup/restore, sharing
